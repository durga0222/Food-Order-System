export enum OrderStatus{
    NEW = 'NEW',
    PAYED = 'PAID',
    SHIPPED = 'SHIPPED',
    CANCELED = 'CANCELED',
    REFUNDED = 'REFUNDED',
  }