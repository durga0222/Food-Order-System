import { Component, Input, OnInit } from '@angular/core';
import { Order } from 'src/app/shared/models/Order';
import Swal from 'sweetalert2';

@Component({
  selector: 'placeorder',
  templateUrl: './placeorder.component.html',
  styleUrls: ['./placeorder.component.css']
})
export class PlaceorderComponent implements OnInit{
  @Input()
  order!:Order;

  constructor(){}

  ngOnInit(): void {

  }
  placeOrder(){
    Swal.fire({
      position: 'top-end',
      icon: 'success',
      title: 'Order Placed Successfully',
      showConfirmButton: false,
      timer: 1500
    })
  }
}
